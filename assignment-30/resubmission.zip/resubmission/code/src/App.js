import './App.css';
import Form from './Form';

function App() {
  return (
    <div id='maindiv'>
      <Form  />
    </div>
  );
}

export default App;
