res = "";
for (i = 100; i >= 1; i--) {
  res += i + " ";
}
res += "<br><br>";
document.writeln("Numbers From 100 to 1 using for loop<br>");
document.writeln(res);
