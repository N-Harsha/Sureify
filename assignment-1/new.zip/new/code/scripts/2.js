res = "";
for (i = 2; i <= 100; i += 2) {
  res += i + " ";
}
res += "<br><br>";
document.writeln("Even Numbers From 1 to 100 using for loop<br>");
document.writeln(res);
