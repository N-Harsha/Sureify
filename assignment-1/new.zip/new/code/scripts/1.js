res = "";
for (i = 1; i <= 100; i += 2) {
  res += i + " ";
}
res += "<br><br>";
document.writeln("Odd Numbers From 1 to 100 using for loop<br>");
document.writeln(res);
