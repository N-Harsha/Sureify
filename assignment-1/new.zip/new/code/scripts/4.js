res = 0;
i = 1;
while (i <= 50) {
  res += i;
  i++;
}
res += "<br><br>";
document.writeln("Sum of All numbers from 1 to 50 using while loop<br>");
document.writeln(res);
